package com.yourname.bikeracinggame.game;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class GameThread extends Thread {

    private static final int TARGET_FPS  = 60;
    private static final long TARGET_TIME = 1000 / TARGET_FPS;

    private final SurfaceHolder surfaceHolder;
    private final GameView gameView;
    private boolean running = false;

    private int fps = 0;
    private long fpsTimer = 0;
    private int frameCount = 0;

    public GameThread(SurfaceHolder surfaceHolder, GameView gameView) {
        super("GameThread");
        this.surfaceHolder = surfaceHolder;
        this.gameView = gameView;
    }

    public void setRunning(boolean running) { this.running = running; }
    public boolean isRunning()              { return running; }
    public int getFPS()                     { return fps; }

    @Override
    public void run() {
        long startTime, elapsedTime, sleepTime;
        fpsTimer = System.currentTimeMillis();

        while (running) {
            startTime = System.nanoTime();
            Canvas canvas = null;
            try {
                canvas = surfaceHolder.lockCanvas();
                if (canvas != null) {
                    synchronized (surfaceHolder) {
                        gameView.update();
                        gameView.draw(canvas);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (canvas != null) {
                    try { surfaceHolder.unlockCanvasAndPost(canvas); }
                    catch (Exception e) { e.printStackTrace(); }
                }
            }

            elapsedTime = (System.nanoTime() - startTime) / 1_000_000;
            sleepTime   = TARGET_TIME - elapsedTime;
            if (sleepTime > 0) {
                try { Thread.sleep(sleepTime); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }

            frameCount++;
            if (System.currentTimeMillis() - fpsTimer >= 1000) {
                fps = frameCount;
                frameCount = 0;
                fpsTimer = System.currentTimeMillis();
            }
        }
    }
}
