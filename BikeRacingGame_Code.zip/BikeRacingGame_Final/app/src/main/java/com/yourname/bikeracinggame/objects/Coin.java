package com.yourname.bikeracinggame.objects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import com.yourname.bikeracinggame.R;

public class Coin {

    private float x, y;
    private final int width = 60, height = 60;
    private Bitmap bitmap;
    private float scaleX = 1f, scaleDir = -0.02f, bobOffset = 0;
    private float glowAlpha = 120;
    private int glowDir = 3;
    private Paint glowPaint;

    public Coin(Context context, int laneX, int startY, float gameSpeed) {
        x = laneX - width / 2f;
        y = startY;
        try {
            bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.coin);
            if (bitmap != null) bitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);
        } catch (Exception e) { bitmap = null; }
        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setColor(Color.parseColor("#FFB300"));
    }

    public void update(float gameSpeed) {
        y += gameSpeed;
        scaleX += scaleDir;
        if (scaleX <= 0.1f) scaleDir = 0.02f;
        if (scaleX >= 1f)   scaleDir = -0.02f;
        bobOffset = (float)(Math.sin(y * 0.08f) * 6f);
        glowAlpha += glowDir;
        if (glowAlpha >= 200) glowDir = -3;
        if (glowAlpha <= 60)  glowDir = 3;
    }

    public void draw(Canvas canvas) {
        float drawY = y + bobOffset;
        float cx = x + width / 2f;
        glowPaint.setAlpha((int) glowAlpha);
        canvas.drawCircle(cx, drawY + height / 2f, width / 2f + 8, glowPaint);
        canvas.save();
        canvas.scale(scaleX, 1f, cx, drawY + height / 2f);
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, x, drawY, null);
        } else {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.parseColor("#FFB300"));
            canvas.drawCircle(cx, drawY + height / 2f, width / 2f, p);
        }
        canvas.restore();
    }

    public boolean isOffScreen(int screenH) { return y > screenH + height; }

    public RectF getBounds() {
        return new RectF(x + 5, y + 5, x + width - 5, y + height - 5);
    }
}
