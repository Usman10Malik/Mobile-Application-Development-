package com.yourname.bikeracinggame.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManager {

    private static final String PREF_NAME       = "BikeRacingPrefs";
    private static final String KEY_HIGH_SCORE  = "high_score";
    private static final String KEY_BEST_COINS  = "best_coins";
    private static final String KEY_SOUND_ON    = "sound_on";

    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;

    public PreferenceManager(Context context) {
        prefs  = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void saveHighScore(int score)    { editor.putInt(KEY_HIGH_SCORE, score).apply(); }
    public int  getHighScore()              { return prefs.getInt(KEY_HIGH_SCORE, 0); }
    public void saveBestCoins(int coins)    { editor.putInt(KEY_BEST_COINS, coins).apply(); }
    public int  getBestCoins()              { return prefs.getInt(KEY_BEST_COINS, 0); }
    public void setSoundEnabled(boolean on) { editor.putBoolean(KEY_SOUND_ON, on).apply(); }
    public boolean isSoundEnabled()         { return prefs.getBoolean(KEY_SOUND_ON, true); }
    public void resetAll()                  { editor.clear().apply(); }
}
