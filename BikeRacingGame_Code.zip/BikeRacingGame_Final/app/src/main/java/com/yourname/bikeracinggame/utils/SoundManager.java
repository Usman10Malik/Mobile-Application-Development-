package com.yourname.bikeracinggame.utils;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;

import com.yourname.bikeracinggame.R;

public class SoundManager {

    private SoundPool soundPool;
    private MediaPlayer enginePlayer;
    private Context context;
    private PreferenceManager preferenceManager;

    private int soundCrash = -1;
    private int soundCoin  = -1;

    public SoundManager(Context context) {
        this.context = context;
        this.preferenceManager = new PreferenceManager(context);
        initSoundPool();
    }

    private void initSoundPool() {
        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();

        soundPool = new SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(attrs)
            .build();

        try {
            soundCrash = soundPool.load(context, R.raw.crash_sound, 1);
            soundCoin  = soundPool.load(context, R.raw.coin_sound, 1);
        } catch (Exception e) {
            // Sound files not yet added — silently ignore
        }

        try {
            enginePlayer = MediaPlayer.create(context, R.raw.engine_sound);
            if (enginePlayer != null) {
                enginePlayer.setLooping(true);
                enginePlayer.setVolume(0.4f, 0.4f);
                if (preferenceManager.isSoundEnabled()) {
                    enginePlayer.start();
                }
            }
        } catch (Exception e) {
            // Sound file missing — silently ignore
        }
    }

    public void playCrash() {
        if (!preferenceManager.isSoundEnabled()) return;
        if (soundPool != null && soundCrash != -1) {
            soundPool.play(soundCrash, 1f, 1f, 1, 0, 1f);
        }
    }

    public void playCoin() {
        if (!preferenceManager.isSoundEnabled()) return;
        if (soundPool != null && soundCoin != -1) {
            soundPool.play(soundCoin, 0.8f, 0.8f, 1, 0, 1f);
        }
    }

    public void pauseEngine() {
        if (enginePlayer != null && enginePlayer.isPlaying()) {
            enginePlayer.pause();
        }
    }

    public void resumeEngine() {
        if (!preferenceManager.isSoundEnabled()) return;
        if (enginePlayer != null && !enginePlayer.isPlaying()) {
            enginePlayer.start();
        }
    }

    public void release() {
        if (enginePlayer != null) {
            enginePlayer.stop();
            enginePlayer.release();
            enginePlayer = null;
        }
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
    }
}
