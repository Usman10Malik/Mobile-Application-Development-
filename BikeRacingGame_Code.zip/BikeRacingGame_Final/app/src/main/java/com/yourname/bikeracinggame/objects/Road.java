package com.yourname.bikeracinggame.objects;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import java.util.Random;

public class Road {

    private int screenW, screenH;
    private float scrollY1, scrollY2;
    private int roadLeft, roadRight, roadWidth;
    private int[] laneXPositions;

    private Paint roadPaint, grassPaint, edgePaint, dashPaint, skyPaint, buildingPaint, starPaint;
    private float scroll;

    public Road(Context context, int screenW, int screenH) {
        this.screenW = screenW;
        this.screenH = screenH;
        this.scrollY1 = 0;
        this.scrollY2 = -screenH;

        roadLeft  = (int)(screenW * 0.1f);
        roadRight = (int)(screenW * 0.9f);
        roadWidth = roadRight - roadLeft;

        int laneW = roadWidth / 3;
        laneXPositions = new int[]{
            roadLeft + laneW / 2,
            roadLeft + laneW + laneW / 2,
            roadLeft + 2 * laneW + laneW / 2
        };

        initPaints();
    }

    private void initPaints() {
        roadPaint = new Paint(); roadPaint.setColor(Color.parseColor("#263238"));
        grassPaint = new Paint(); grassPaint.setColor(Color.parseColor("#1B5E20"));
        edgePaint = new Paint(); edgePaint.setColor(Color.WHITE);
        dashPaint = new Paint(); dashPaint.setColor(Color.parseColor("#FFEB3B")); dashPaint.setStrokeWidth(5f);
        skyPaint = new Paint(); skyPaint.setColor(Color.parseColor("#0D1B2A"));
        buildingPaint = new Paint(); buildingPaint.setColor(Color.parseColor("#0A1628"));
        starPaint = new Paint(Paint.ANTI_ALIAS_FLAG); starPaint.setColor(Color.WHITE); starPaint.setAlpha(200);
    }

    public void update(float speed) {
        scroll = speed * 3f;
        scrollY1 += scroll; scrollY2 += scroll;
        if (scrollY1 >= screenH) scrollY1 = scrollY2 - screenH;
        if (scrollY2 >= screenH) scrollY2 = scrollY1 - screenH;
    }

    public void draw(Canvas canvas) {
        // Sky
        canvas.drawRect(0, 0, screenW, screenH * 0.35f, skyPaint);
        drawStars(canvas);
        drawCitySilhouette(canvas);

        // Grass
        canvas.drawRect(0, 0, roadLeft, screenH, grassPaint);
        canvas.drawRect(roadRight, 0, screenW, screenH, grassPaint);

        // Road tiles
        drawRoadSegment(canvas, scrollY1);
        drawRoadSegment(canvas, scrollY2);

        // Edge lines
        canvas.drawRect(roadLeft, 0, roadLeft + 8, screenH, edgePaint);
        canvas.drawRect(roadRight - 8, 0, roadRight, screenH, edgePaint);

        drawRumbleStrips(canvas);
    }

    private void drawRoadSegment(Canvas canvas, float offsetY) {
        canvas.drawRect(roadLeft, offsetY, roadRight, offsetY + screenH, roadPaint);
        int laneW = roadWidth / 3;
        drawDashedLine(canvas, roadLeft + laneW, offsetY);
        drawDashedLine(canvas, roadLeft + laneW * 2, offsetY);
    }

    private void drawDashedLine(Canvas canvas, float x, float offsetY) {
        float dashH = 80f, gapH = 60f, startY = offsetY;
        while (startY < screenH + offsetY + screenH) {
            canvas.drawRect(x - 3, startY, x + 3, startY + dashH, dashPaint);
            startY += dashH + gapH;
        }
    }

    private void drawRumbleStrips(Canvas canvas) {
        Paint red = new Paint(); red.setColor(Color.parseColor("#FF1744"));
        Paint white = new Paint(); white.setColor(Color.WHITE);
        float segH = 40f, y = scrollY1 % (segH * 2);
        while (y < screenH) {
            Paint p = ((int)(y / segH) % 2 == 0) ? red : white;
            canvas.drawRect(roadLeft - 18, y, roadLeft, y + segH, p);
            canvas.drawRect(roadRight, y, roadRight + 18, y + segH, p);
            y += segH;
        }
    }

    private void drawStars(Canvas canvas) {
        int[] sx = {40,80,130,180,220,270,310,350,20,390};
        int[] sy = {20,50,30,15,45,25,40,10,55,35};
        for (int i = 0; i < sx.length; i++) canvas.drawCircle(sx[i], sy[i], 2.5f, starPaint);
    }

    private void drawCitySilhouette(Canvas canvas) {
        float baseY = screenH * 0.32f;
        int[] bx = {10,40,70,100,130,160,190,220,250,280,310,340,370};
        int[] bh = {80,120,60,100,90,140,70,110,85,130,75,95,65};
        int[] bw = {28,25,30,22,26,20,28,24,26,22,28,25,30};
        for (int i = 0; i < bx.length; i++)
            canvas.drawRect(bx[i], baseY - bh[i], bx[i] + bw[i], baseY, buildingPaint);
    }

    public int getRoadLeft()  { return roadLeft; }
    public int getRoadRight() { return roadRight; }

    public int getRandomLaneX(Random random) {
        return laneXPositions[random.nextInt(laneXPositions.length)];
    }
}
