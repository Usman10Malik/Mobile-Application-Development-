package com.yourname.bikeracinggame.effects;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ExplosionEffect {

    private float cx, cy, radius = 0, alpha = 255;
    private boolean done = false;
    private Paint firePaint, sparkPaint;
    private List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();

    private static class Particle {
        float x, y, vx, vy, size, alpha, decay;
        int color;
    }

    public ExplosionEffect(int cx, int cy) {
        this.cx = cx; this.cy = cy;
        firePaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
        sparkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        spawnParticles();
    }

    private void spawnParticles() {
        int[] fireColors  = {0xFFFF6D00, 0xFFFF8F00, 0xFFFFB300, 0xFFFFD740};
        int[] smokeColors = {0xFF424242, 0xFF616161, 0xFF757575};
        for (int i = 0; i < 24; i++) {
            Particle p = new Particle();
            double angle = Math.random() * Math.PI * 2;
            double speed = 3 + Math.random() * 8;
            p.x = cx; p.y = cy;
            p.vx = (float)(Math.cos(angle) * speed);
            p.vy = (float)(Math.sin(angle) * speed) - 2f;
            p.size = 6f + (float)(Math.random() * 14f);
            p.alpha = 255f;
            p.decay = 4f + (float)(Math.random() * 4f);
            p.color = (i % 3 == 0)
                ? smokeColors[random.nextInt(smokeColors.length)]
                : fireColors[random.nextInt(fireColors.length)];
            particles.add(p);
        }
        for (int i = 0; i < 12; i++) {
            Particle s = new Particle();
            double angle = Math.random() * Math.PI * 2;
            double speed = 8 + Math.random() * 14;
            s.x = cx; s.y = cy;
            s.vx = (float)(Math.cos(angle) * speed);
            s.vy = (float)(Math.sin(angle) * speed);
            s.size = 3f; s.alpha = 255f;
            s.decay = 6f + (float)(Math.random() * 6f);
            s.color = 0xFFFFD740;
            particles.add(s);
        }
    }

    public void update() {
        radius += 6f; alpha -= 8f;
        for (Particle p : particles) {
            p.x += p.vx; p.y += p.vy;
            p.vy += 0.3f; p.vx *= 0.95f;
            p.alpha -= p.decay; p.size *= 0.97f;
        }
        if (alpha <= 0 && radius >= 120f) done = true;
    }

    public void draw(Canvas canvas) {
        if (done) return;
        if (alpha > 0) {
            firePaint.setColor(Color.parseColor("#FF8F00"));
            firePaint.setAlpha(Math.max(0, (int) alpha));
            canvas.drawCircle(cx, cy, radius * 0.5f, firePaint);
            firePaint.setColor(Color.parseColor("#FFD740"));
            firePaint.setAlpha(Math.max(0, (int)(alpha * 0.6f)));
            canvas.drawCircle(cx, cy, radius * 0.3f, firePaint);
        }
        for (Particle p : particles) {
            if (p.alpha <= 0) continue;
            sparkPaint.setColor(p.color);
            sparkPaint.setAlpha(Math.max(0, (int) p.alpha));
            canvas.drawCircle(p.x, p.y, p.size, sparkPaint);
        }
    }

    public boolean isDone() { return done; }
}
