package com.yourname.bikeracinggame.utils;

import android.graphics.RectF;

public class CollisionDetector {

    public boolean check(RectF a, RectF b) {
        if (a == null || b == null) return false;
        return RectF.intersects(a, b);
    }

    public boolean checkCircle(float ax, float ay, float ar, float bx, float by, float br) {
        float dx = ax - bx, dy = ay - by;
        float distSq = dx * dx + dy * dy;
        float radSum = ar + br;
        return distSq <= radSum * radSum;
    }
}
