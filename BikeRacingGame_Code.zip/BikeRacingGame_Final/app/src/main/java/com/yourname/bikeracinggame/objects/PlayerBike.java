package com.yourname.bikeracinggame.objects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import com.yourname.bikeracinggame.R;

public class PlayerBike {

    private float x, y;
    private final int width = 100, height = 140;
    private Bitmap bitmap;
    private boolean flashing = false;
    private int flashCount = 0;
    private static final int FLASH_DURATION = 30;
    private float tiltAngle = 0f, targetTiltAngle = 0f;
    private int roadLeft = 80, roadRight;

    public PlayerBike(Context context, int screenW, int screenH) {
        roadRight = screenW - 80;
        x = screenW / 2f - width / 2f;
        y = screenH - height - 100;
        try {
            bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.player_bike);
            if (bitmap != null) bitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);
        } catch (Exception e) { bitmap = null; }
    }

    public void update(int screenW) {
        if (x < roadLeft) x = roadLeft;
        if (x + width > roadRight) x = roadRight - width;
        tiltAngle += (targetTiltAngle - tiltAngle) * 0.15f;
        targetTiltAngle *= 0.85f;
        if (flashing) { flashCount++; if (flashCount >= FLASH_DURATION) { flashing = false; flashCount = 0; } }
    }

    public void moveBy(float dx) {
        x += dx;
        targetTiltAngle = dx * 0.3f;
        if (targetTiltAngle > 20f) targetTiltAngle = 20f;
        if (targetTiltAngle < -20f) targetTiltAngle = -20f;
    }

    public void draw(Canvas canvas) {
        if (flashing && (flashCount / 4) % 2 == 0) return;
        canvas.save();
        canvas.rotate(tiltAngle, x + width / 2f, y + height / 2f);
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, x, y, null);
        } else {
            Paint p = new Paint();
            p.setColor(Color.parseColor("#1565C0"));
            canvas.drawRoundRect(x, y, x + width, y + height, 16, 16, p);
        }
        drawExhaustFlame(canvas);
        canvas.restore();
    }

    private void drawExhaustFlame(Canvas canvas) {
        Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG);
        fp.setColor(Color.parseColor("#FF6D00")); fp.setAlpha(180);
        canvas.drawOval(x + 30, y + height, x + 70, y + height + 30, fp);
        fp.setColor(Color.parseColor("#FFD700")); fp.setAlpha(120);
        canvas.drawOval(x + 38, y + height + 5, x + 62, y + height + 22, fp);
    }

    public void flash() { flashing = true; flashCount = 0; }

    public RectF getBounds() {
        return new RectF(x + 10, y + 10, x + width - 10, y + height - 10);
    }
}
