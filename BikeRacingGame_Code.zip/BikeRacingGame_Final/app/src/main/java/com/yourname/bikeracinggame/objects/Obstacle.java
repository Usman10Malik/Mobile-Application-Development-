package com.yourname.bikeracinggame.objects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import com.yourname.bikeracinggame.R;

public class Obstacle {

    private float x, y, rotation = 0;
    private final int width = 80, height = 110;
    private Bitmap bitmap;

    public Obstacle(Context context, int laneX, int startY, float gameSpeed) {
        x = laneX - width / 2f;
        y = startY;
        try {
            bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.obstacle);
            if (bitmap != null) bitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);
        } catch (Exception e) { bitmap = null; }
    }

    public void update(float gameSpeed) { y += gameSpeed; rotation += 1f; }

    public void draw(Canvas canvas) {
        canvas.save();
        canvas.rotate(rotation % 5f - 2.5f, x + width / 2f, y + height / 2f);
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, x, y, null);
        } else {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.parseColor("#E64A19"));
            canvas.drawRoundRect(x, y, x + width, y + height, 10, 10, p);
        }
        Paint wp = new Paint(Paint.ANTI_ALIAS_FLAG);
        wp.setColor(Color.parseColor("#FF1744")); wp.setAlpha(50);
        canvas.drawOval(x - 10, y + height - 20, x + width + 10, y + height + 20, wp);
        canvas.restore();
    }

    public boolean isOffScreen(int screenH) { return y > screenH + height; }

    public RectF getBounds() {
        return new RectF(x + 10, y + 10, x + width - 10, y + height - 10);
    }
}
