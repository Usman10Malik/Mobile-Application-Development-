package com.yourname.bikeracinggame.game;

public class GameManager {

    public enum GameState { READY, PLAYING, PAUSED, GAME_OVER }

    private GameState gameState = GameState.READY;
    private int score = 0, coins = 0, lives = 3, maxSpeed = 0, frameCount = 0;
    private float speed = 5f;
    private long distance = 0;

    private static final float MAX_SPEED       = 22f;
    private static final float SPEED_INCREMENT = 0.0008f;

    public GameManager() { reset(); }

    public void reset() {
        gameState  = GameState.READY;
        score = coins = maxSpeed = frameCount = 0;
        lives = 3;
        speed = 5f;
        distance = 0;
    }

    public void startGame() { gameState = GameState.PLAYING; }

    public void update() {
        if (gameState != GameState.PLAYING) return;
        frameCount++;
        score++;
        if (speed < MAX_SPEED) speed += SPEED_INCREMENT;
        distance += (long) speed;
        int currentSpeedKmh = (int)(speed * 10);
        if (currentSpeedKmh > maxSpeed) maxSpeed = currentSpeedKmh;
    }

    public void addCoin()    { coins++; score += 50; }

    public void loseLife() {
        lives--;
        if (lives <= 0) { lives = 0; gameState = GameState.GAME_OVER; }
    }

    public void pauseGame()  { if (gameState == GameState.PLAYING)  gameState = GameState.PAUSED; }
    public void resumeGame() { if (gameState == GameState.PAUSED)   gameState = GameState.PLAYING; }
    public void setGameOver(){ gameState = GameState.GAME_OVER; }

    public GameState getGameState()  { return gameState; }
    public int       getScore()      { return score; }
    public int       getCoins()      { return coins; }
    public int       getLives()      { return lives; }
    public float     getSpeed()      { return speed; }
    public int       getMaxSpeed()   { return maxSpeed; }
    public long      getDistance()   { return distance; }
    public int       getFrameCount() { return frameCount; }
    public boolean   isPlaying()     { return gameState == GameState.PLAYING; }
    public boolean   isGameOver()    { return gameState == GameState.GAME_OVER; }

    public int getDifficultyLevel() {
        if (score < 500)  return 1;
        if (score < 1500) return 2;
        if (score < 3000) return 3;
        if (score < 5000) return 4;
        return 5;
    }
}
