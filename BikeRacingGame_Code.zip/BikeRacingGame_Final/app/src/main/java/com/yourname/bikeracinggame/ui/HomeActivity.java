package com.yourname.bikeracinggame.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.yourname.bikeracinggame.R;
import com.yourname.bikeracinggame.game.GameActivity;
import com.yourname.bikeracinggame.utils.PreferenceManager;

public class HomeActivity extends AppCompatActivity {

    private Button btnPlay, btnHighScore, btnExit;
    private TextView tvHighScore;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home);

        preferenceManager = new PreferenceManager(this);
        initViews();
        setHighScore();
        animateUI();
        setListeners();
    }

    private void initViews() {
        btnPlay      = findViewById(R.id.btnPlay);
        btnHighScore = findViewById(R.id.btnHighScore);
        btnExit      = findViewById(R.id.btnExit);
        tvHighScore  = findViewById(R.id.tvHighScore);
    }

    private void setHighScore() {
        tvHighScore.setText(String.valueOf(preferenceManager.getHighScore()));
    }

    private void animateUI() {
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(800);
        fadeIn.setFillAfter(true);
        findViewById(android.R.id.content).startAnimation(fadeIn);

        TranslateAnimation slideUp = new TranslateAnimation(0, 0, 100, 0);
        slideUp.setDuration(600);
        slideUp.setStartOffset(400);
        slideUp.setFillAfter(true);
        btnPlay.startAnimation(slideUp);
    }

    private void setListeners() {
        btnPlay.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, GameActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });

        btnHighScore.setOnClickListener(v ->
            new AlertDialog.Builder(this)
                .setTitle("HIGH SCORE")
                .setMessage("Best Score: " + preferenceManager.getHighScore()
                    + "\nBest Coins: " + preferenceManager.getBestCoins())
                .setPositiveButton("OK", null)
                .show()
        );

        btnExit.setOnClickListener(v -> finishAffinity());
    }

    @Override
    protected void onResume() {
        super.onResume();
        setHighScore();
    }
}
