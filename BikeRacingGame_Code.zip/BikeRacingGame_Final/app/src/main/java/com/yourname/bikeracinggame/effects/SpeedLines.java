package com.yourname.bikeracinggame.effects;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SpeedLines {

    private int screenW, screenH;
    private List<SpeedLine> lines = new ArrayList<>();
    private final Random random = new Random();
    private float currentSpeed = 0;

    private static class SpeedLine {
        float x, y, length, alpha, speed;
    }

    public SpeedLines(int screenW, int screenH) {
        this.screenW = screenW;
        this.screenH = screenH;
        for (int i = 0; i < 20; i++) spawnLine();
    }

    private void spawnLine() {
        SpeedLine line = new SpeedLine();
        line.x      = random.nextInt(screenW);
        line.y      = random.nextInt(screenH);
        line.length = 30f + random.nextFloat() * 80f;
        line.alpha  = 40f + random.nextFloat() * 80f;
        line.speed  = 8f + random.nextFloat() * 12f;
        lines.add(line);
    }

    public void update(float gameSpeed) {
        currentSpeed = gameSpeed;
        for (SpeedLine line : lines) {
            line.y += line.speed * (gameSpeed / 8f);
            if (line.y > screenH + line.length) {
                line.y = -line.length;
                line.x = random.nextInt(screenW);
                line.length = 30f + random.nextFloat() * 80f;
                line.alpha  = 40f + random.nextFloat() * 80f;
            }
        }
    }

    public void draw(Canvas canvas) {
        if (currentSpeed < 8f) return;
        float intensity = Math.min(1f, (currentSpeed - 8f) / 14f);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(2f);

        for (SpeedLine line : lines) {
            paint.setAlpha((int)(line.alpha * intensity));
            canvas.drawLine(line.x, line.y, line.x, line.y + line.length, paint);
        }
    }
}
