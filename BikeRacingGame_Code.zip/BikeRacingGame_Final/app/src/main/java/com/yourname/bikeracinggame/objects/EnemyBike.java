package com.yourname.bikeracinggame.objects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import com.yourname.bikeracinggame.R;

public class EnemyBike {

    private float x, y;
    private final int width = 90, height = 130;
    private float speedMultiplier, waveOffset, waveSpeed, waveAmplitude;
    private Bitmap bitmap;

    public EnemyBike(Context context, int laneX, int startY, float gameSpeed) {
        x = laneX - width / 2f;
        y = startY;
        speedMultiplier = 0.7f + (float)(Math.random() * 0.5f);
        waveSpeed       = 0.03f + (float)(Math.random() * 0.04f);
        waveAmplitude   = 8f + (float)(Math.random() * 12f);
        try {
            bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.enemy_bike);
            if (bitmap != null) bitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);
        } catch (Exception e) { bitmap = null; }
    }

    public void update(float gameSpeed) {
        y += gameSpeed * speedMultiplier;
        waveOffset += waveSpeed;
        x += (float) Math.sin(waveOffset) * waveAmplitude * 0.1f;
    }

    public void draw(Canvas canvas) {
        if (bitmap != null) {
            canvas.drawBitmap(bitmap, x, y, null);
        } else {
            Paint p = new Paint();
            p.setColor(Color.parseColor("#212121"));
            canvas.drawRoundRect(x, y, x + width, y + height, 16, 16, p);
        }
        Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
        gp.setColor(Color.parseColor("#FF6D00")); gp.setAlpha(80);
        canvas.drawCircle(x + width / 2f, y + height - 10, 20f, gp);
    }

    public boolean isOffScreen(int screenH) { return y > screenH + height; }

    public RectF getBounds() {
        return new RectF(x + 8, y + 8, x + width - 8, y + height - 8);
    }
}
