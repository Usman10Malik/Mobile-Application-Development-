package com.yourname.bikeracinggame.game;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.yourname.bikeracinggame.effects.ExplosionEffect;
import com.yourname.bikeracinggame.effects.SpeedLines;
import com.yourname.bikeracinggame.objects.Coin;
import com.yourname.bikeracinggame.objects.EnemyBike;
import com.yourname.bikeracinggame.objects.Obstacle;
import com.yourname.bikeracinggame.objects.PlayerBike;
import com.yourname.bikeracinggame.objects.Road;
import com.yourname.bikeracinggame.ui.GameOverActivity;
import com.yourname.bikeracinggame.utils.CollisionDetector;
import com.yourname.bikeracinggame.utils.SoundManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private GameThread gameThread;
    private GameManager gameManager;
    private SoundManager soundManager;
    private CollisionDetector collisionDetector;

    private Road road;
    private PlayerBike playerBike;
    private List<EnemyBike> enemyBikes    = new ArrayList<>();
    private List<Obstacle>  obstacles     = new ArrayList<>();
    private List<Coin>      coins         = new ArrayList<>();
    private List<ExplosionEffect> explosions = new ArrayList<>();
    private SpeedLines speedLines;

    private Paint scorePaint, labelPaint, hudBgPaint, speedPaint, livesHeartPaint, coinHudPaint;
    private int screenW, screenH;
    private float touchStartX;
    private boolean touchActive = false;
    private int spawnCounter = 0, coinSpawnCounter = 0;
    private final Random random = new Random();

    public GameView(Context context) {
        super(context);
        getHolder().addCallback(this);
        setFocusable(true);
        gameManager      = new GameManager();
        soundManager     = new SoundManager(context);
        collisionDetector = new CollisionDetector();
        initPaints();
    }

    private void initPaints() {
        scorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        scorePaint.setColor(Color.parseColor("#FFD700"));
        scorePaint.setTextSize(72f);
        scorePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        scorePaint.setTextAlign(Paint.Align.CENTER);

        labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        labelPaint.setColor(Color.parseColor("#9CA3AF"));
        labelPaint.setTextSize(28f);
        labelPaint.setTextAlign(Paint.Align.CENTER);

        speedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        speedPaint.setColor(Color.parseColor("#00E5FF"));
        speedPaint.setTextSize(36f);
        speedPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        speedPaint.setTextAlign(Paint.Align.CENTER);

        hudBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hudBgPaint.setColor(Color.parseColor("#CC111827"));

        livesHeartPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        livesHeartPaint.setColor(Color.parseColor("#EF4444"));
        livesHeartPaint.setTextSize(40f);
        livesHeartPaint.setTextAlign(Paint.Align.CENTER);

        coinHudPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        coinHudPaint.setColor(Color.parseColor("#FFB300"));
        coinHudPaint.setTextSize(36f);
        coinHudPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        screenW = getWidth();
        screenH = getHeight();
        road       = new Road(getContext(), screenW, screenH);
        playerBike = new PlayerBike(getContext(), screenW, screenH);
        speedLines = new SpeedLines(screenW, screenH);
        gameManager.startGame();
        gameThread = new GameThread(getHolder(), this);
        gameThread.setRunning(true);
        gameThread.start();
    }

    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int ht) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        stopThread();
        soundManager.release();
    }

    private void stopThread() {
        boolean retry = true;
        if (gameThread != null) {
            gameThread.setRunning(false);
            while (retry) {
                try { gameThread.join(); retry = false; }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }
        }
    }

    // ── UPDATE ────────────────────────────────────────────────────
    public void update() {
        if (!gameManager.isPlaying()) return;
        gameManager.update();
        float speed = gameManager.getSpeed();

        road.update(speed);
        playerBike.update(screenW);
        speedLines.update(speed);

        // Spawn enemies
        spawnCounter++;
        int spawnRate = Math.max(60, 120 - gameManager.getDifficultyLevel() * 10);
        if (spawnCounter >= spawnRate) { spawnCounter = 0; spawnEnemy(speed); }

        // Spawn obstacles
        if (gameManager.getFrameCount() % 90 == 0) spawnObstacle(speed);

        // Spawn coins
        coinSpawnCounter++;
        if (coinSpawnCounter >= 80) { coinSpawnCounter = 0; spawnCoin(speed); }

        // Update & check enemies
        Iterator<EnemyBike> ei = enemyBikes.iterator();
        while (ei.hasNext()) {
            EnemyBike e = ei.next();
            e.update(speed);
            if (e.isOffScreen(screenH)) { ei.remove(); continue; }
            if (collisionDetector.check(playerBike.getBounds(), e.getBounds())) {
                handleCrash(); ei.remove();
            }
        }

        // Update & check obstacles
        Iterator<Obstacle> oi = obstacles.iterator();
        while (oi.hasNext()) {
            Obstacle o = oi.next();
            o.update(speed);
            if (o.isOffScreen(screenH)) { oi.remove(); continue; }
            if (collisionDetector.check(playerBike.getBounds(), o.getBounds())) {
                handleCrash(); oi.remove();
            }
        }

        // Update & check coins
        Iterator<Coin> ci = coins.iterator();
        while (ci.hasNext()) {
            Coin c = ci.next();
            c.update(speed);
            if (c.isOffScreen(screenH)) { ci.remove(); continue; }
            if (collisionDetector.check(playerBike.getBounds(), c.getBounds())) {
                gameManager.addCoin(); soundManager.playCoin(); ci.remove();
            }
        }

        // Update explosions
        Iterator<ExplosionEffect> xi = explosions.iterator();
        while (xi.hasNext()) { ExplosionEffect x = xi.next(); x.update(); if (x.isDone()) xi.remove(); }

        if (gameManager.isGameOver()) navigateToGameOver();
    }

    private void spawnEnemy(float speed)    { enemyBikes.add(new EnemyBike(getContext(), road.getRandomLaneX(random), -200, speed)); }
    private void spawnObstacle(float speed) { obstacles.add(new Obstacle(getContext(), road.getRandomLaneX(random), -150, speed)); }
    private void spawnCoin(float speed)     { coins.add(new Coin(getContext(), road.getRandomLaneX(random), -100, speed)); }

    private void handleCrash() {
        RectF pb = playerBike.getBounds();
        explosions.add(new ExplosionEffect((int) pb.centerX(), (int) pb.centerY()));
        soundManager.playCrash();
        gameManager.loseLife();
        playerBike.flash();
    }

    private void navigateToGameOver() {
        stopThread();
        soundManager.release();
        post(() -> {
            Intent intent = new Intent(getContext(), GameOverActivity.class);
            intent.putExtra(GameOverActivity.EXTRA_SCORE,     gameManager.getScore());
            intent.putExtra(GameOverActivity.EXTRA_COINS,     gameManager.getCoins());
            intent.putExtra(GameOverActivity.EXTRA_MAX_SPEED, gameManager.getMaxSpeed());
            getContext().startActivity(intent);
            ((Activity) getContext()).overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            ((Activity) getContext()).finish();
        });
    }

    // ── DRAW ──────────────────────────────────────────────────────
    @Override
    public void draw(Canvas canvas) {
        if (canvas == null) return;
        super.draw(canvas);

        road.draw(canvas);
        if (gameManager.getSpeed() > 10f) speedLines.draw(canvas);

        for (Coin c : coins)             c.draw(canvas);
        for (Obstacle o : obstacles)     o.draw(canvas);
        for (EnemyBike e : enemyBikes)   e.draw(canvas);
        playerBike.draw(canvas);
        for (ExplosionEffect x : explosions) x.draw(canvas);

        drawHUD(canvas);
    }

    private void drawHUD(Canvas canvas) {
        canvas.drawRoundRect(16, 16, screenW - 16, 130, 16, 16, hudBgPaint);

        canvas.drawText("SCORE", screenW / 2f, 55, labelPaint);
        canvas.drawText(String.valueOf(gameManager.getScore()), screenW / 2f, 115, scorePaint);

        canvas.drawText("SPEED", 100, 55, labelPaint);
        canvas.drawText((int)(gameManager.getSpeed() * 10) + " km/h", 100, 100, speedPaint);

        canvas.drawText("LIVES", screenW - 100f, 55, labelPaint);
        int lv = gameManager.getLives();
        String hearts = lv >= 3 ? "* * *" : lv == 2 ? "* *  " : lv == 1 ? "*    " : "     ";
        canvas.drawText(hearts, screenW - 100f, 105, livesHeartPaint);

        canvas.drawText("COINS: " + gameManager.getCoins(), 80, screenH - 30f, coinHudPaint);
    }

    // ── TOUCH ─────────────────────────────────────────────────────
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                touchStartX = event.getX();
                touchActive = true;
                if (gameManager.getGameState() == GameManager.GameState.READY) gameManager.startGame();
                break;
            case MotionEvent.ACTION_MOVE:
                if (touchActive && gameManager.isPlaying()) {
                    float dx = event.getX() - touchStartX;
                    playerBike.moveBy(dx * 0.6f);
                    touchStartX = event.getX();
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                touchActive = false;
                break;
        }
        return true;
    }

    public void pause()  { gameManager.pauseGame(); }
    public void resume() { gameManager.resumeGame(); }
}
