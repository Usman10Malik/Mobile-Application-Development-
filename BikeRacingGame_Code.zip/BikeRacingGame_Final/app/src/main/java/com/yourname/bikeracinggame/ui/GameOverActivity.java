package com.yourname.bikeracinggame.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.BounceInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.yourname.bikeracinggame.R;
import com.yourname.bikeracinggame.game.GameActivity;
import com.yourname.bikeracinggame.utils.PreferenceManager;

public class GameOverActivity extends AppCompatActivity {

    public static final String EXTRA_SCORE     = "score";
    public static final String EXTRA_COINS     = "coins";
    public static final String EXTRA_MAX_SPEED = "max_speed";

    private TextView tvScore, tvBestScore, tvCoins, tvMaxSpeed, tvNewRecord;
    private Button btnRestart, btnHome;
    private PreferenceManager preferenceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_game_over);

        preferenceManager = new PreferenceManager(this);
        initViews();
        loadResults();
        animateScore();
        setListeners();
    }

    private void initViews() {
        tvScore     = findViewById(R.id.tvScore);
        tvBestScore = findViewById(R.id.tvBestScore);
        tvCoins     = findViewById(R.id.tvCoins);
        tvMaxSpeed  = findViewById(R.id.tvMaxSpeed);
        tvNewRecord = findViewById(R.id.tvNewRecord);
        btnRestart  = findViewById(R.id.btnRestart);
        btnHome     = findViewById(R.id.btnHome);
    }

    private void loadResults() {
        int score    = getIntent().getIntExtra(EXTRA_SCORE, 0);
        int coins    = getIntent().getIntExtra(EXTRA_COINS, 0);
        int maxSpeed = getIntent().getIntExtra(EXTRA_MAX_SPEED, 0);

        tvScore.setText(String.valueOf(score));
        tvCoins.setText(String.valueOf(coins));
        tvMaxSpeed.setText(maxSpeed + " km/h");

        if (score > preferenceManager.getHighScore()) {
            preferenceManager.saveHighScore(score);
            tvNewRecord.setVisibility(View.VISIBLE);
        }
        if (coins > preferenceManager.getBestCoins()) {
            preferenceManager.saveBestCoins(coins);
        }
        tvBestScore.setText(String.valueOf(preferenceManager.getHighScore()));
    }

    private void animateScore() {
        ScaleAnimation bounce = new ScaleAnimation(0.3f, 1f, 0.3f, 1f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
                ScaleAnimation.RELATIVE_TO_SELF, 0.5f);
        bounce.setDuration(700);
        bounce.setInterpolator(new BounceInterpolator());
        tvScore.startAnimation(bounce);

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(500);
        fadeIn.setFillAfter(true);
        findViewById(R.id.gameOverCard).startAnimation(fadeIn);
    }

    private void setListeners() {
        btnRestart.setOnClickListener(v -> {
            Intent intent = new Intent(GameOverActivity.this, GameActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        });

        btnHome.setOnClickListener(v -> {
            Intent intent = new Intent(GameOverActivity.this, HomeActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(GameOverActivity.this, HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}
